# hello-world

SUP!
I'm Analicia! 
I love food, (obvoiusly).
I am pretty quite but i am willing to learn 
and be somewhat helpful.
